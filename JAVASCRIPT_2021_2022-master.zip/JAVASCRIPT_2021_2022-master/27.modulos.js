import {perro} from './28.modulos1.js'
import r from './29.modulos2.js'
import {sumar} from './30.modulos2.js'


console.log(perro.ladrar())

console.log(r(4,5))


console.log(sumar(3,5))