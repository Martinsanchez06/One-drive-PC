//Concatenación tradicional 

let frase="Me gusta mucho pasear "
let frase2=" , por la playa"

let fraseTotal=frase + frase2

console.log(fraseTotal)
document.write(fraseTotal)

let sitio='al cine'
let frase3=`Me gusta ir mucho  ${sitio}`

let sitio4='al campo'
let frase5='Me gusta ir mucho '+ sitio4 + ' por la noche'

console.log(frase3)
console.log(frase5)



