const datos=['persona',34,true]

console.log(datos)


const empresa=[
    {
      id:0,
      nombre:"Javier",
      apellidos:"Garcia Gutierrez",
      edad:34   
    },
    {
        id:1,
        nombre:"Pedro",
        apellidos:"Perez Gómez",
        edad:34   
      },
      {
        id:2,
        nombre:"Andres",
        apellidos:"Segovia Lopez",
        edad:34   
      }
  
]

console.log(empresa)