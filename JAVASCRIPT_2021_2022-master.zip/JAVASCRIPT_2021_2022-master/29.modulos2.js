

export default function restar(numero1,numero2){
    console.log(numero1-numero2)
}

export function sumar(numero1,numero2){
    console.log(numero1+numero2)
}