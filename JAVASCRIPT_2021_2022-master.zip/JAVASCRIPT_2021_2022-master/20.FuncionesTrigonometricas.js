/*
FUNCIONES TRIGONOMETRICAS  

Calculo de hipotenusa: Math.hypot(xB-xA,yB-yA)
Calculo de arco tangente: Math.atan2(y,x)
Calculo de seno: Math.sin(arcoTangente)
calculo del coseno:Math.cos(arcoTangente)

*/ 